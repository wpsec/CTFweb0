<?php
	phpinfo();



?>
