<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>

</head>
<body>
<form action="login.php" method="post">
    <input type="text" name="hao" maxlength="0" disabled="disabled">
    <input type="submit">
</form>
<!--zhimakaimen-->
<div>html长度限制</div>
</body>
</html>

